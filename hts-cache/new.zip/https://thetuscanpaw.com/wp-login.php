<!DOCTYPE html>
	<html lang="it-IT">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Accedi &lsaquo; The Tuscan Paw &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/cart-frontend.js?ver=4e031729927ec3a04970' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-cart-checkout-base-frontend.js?ver=7d01b022a3ccdebeef08' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-cart-checkout-vendors-frontend.js?ver=d8b1ce115c3935c88bec' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/vendor/react.min.js?ver=18.3.1.1' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/vendor/react-jsx-runtime.min.js?ver=18.3.1' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/blocks-checkout.js?ver=831c209cc1dd2f820fc4' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/vendor/react-dom.min.js?ver=18.3.1.1' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/blocks-components.js?ver=150bd47634d08fcc2dfc' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-data.js?ver=6a989f68440048d30473' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/blocks-checkout-events.js?ver=2d0fd4590f6cc663947c' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-types.js?ver=35dee88875b85ff65531' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-registry.js?ver=96479001b0fbd0c70f36' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-settings.js?ver=4f2e7067bd1c84cca43f' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/api-fetch.min.js?ver=3623a576c78df404ff20' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/url.min.js?ver=6bf93e90403a1eec6501' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/data.min.js?ver=fe6c4835cd00e12493c3' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/compose.min.js?ver=84bcf832a5c99203f3db' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/deprecated.min.js?ver=e1f84915c5e8ae38964c' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/dom.min.js?ver=f3a673a30f968c8fa314' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/element.min.js?ver=a4eeeadd23c0d7ab1d2d' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/escape-html.min.js?ver=6561a406d2d232a6fbd2' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/is-shallow-equal.min.js?ver=e0f9f1d78d83f5196979' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/keycodes.min.js?ver=034ff647a54b018581d3' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/priority-queue.min.js?ver=9c21c957c7e50ffdbf48' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/private-apis.min.js?ver=0f8478f1ba7e0eea562b' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/redux-routine.min.js?ver=8bb92d45458b29590f53' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/data-controls.min.js?ver=49f5587e8b90f9e7cc7e' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/html-entities.min.js?ver=2cd3358363e0675638fb' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/notices.min.js?ver=673a68a7ac2f556ed50b' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-middleware.js?ver=d79dedade2f2e4dc9df4' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/primitives.min.js?ver=aef2543ab60c8c9bb609' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/warning.min.js?ver=ed7c8b0940914f4fe44b' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-shared-context.js?ver=1d9ff4f03584490ad390' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-shared-hocs.js?ver=99a2a0de38bfa707fc7b' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-content/plugins/woocommerce/assets/client/blocks/price-format.js?ver=5f0dedeb373c5bb189ff' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/autop.min.js?ver=9fb50649848277dd318d' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/plugins.min.js?ver=20303a2de19246c83e5a' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/style-engine.min.js?ver=08cc10e9532531e22456' as='script' rel='prefetch' />
<link href='https://thetuscanpaw.com/wp-includes/js/dist/wordcount.min.js?ver=55d8c2bf3dc99e7ea5ec' as='script' rel='prefetch' />
<link rel='stylesheet' id='blocksy-dynamic-global-css' href='https://thetuscanpaw.com/wp-content/uploads/blocksy/css/global.css?ver=15862' media='all' />
<link rel='stylesheet' id='wc-blocks-integration-css' href='https://thetuscanpaw.com/wp-content/plugins/woocommerce-subscriptions/build/index.css?ver=8.3.0' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://thetuscanpaw.com/wp-includes/css/dashicons.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://thetuscanpaw.com/wp-includes/css/buttons.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='forms-css' href='https://thetuscanpaw.com/wp-admin/css/forms.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://thetuscanpaw.com/wp-admin/css/l10n.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='login-css' href='https://thetuscanpaw.com/wp-admin/css/login.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='wc-stripe-blocks-checkout-style-css' href='https://thetuscanpaw.com/wp-content/plugins/woocommerce-gateway-stripe/build/upe-blocks.css?ver=4d7a9b7de9f3f44a14aa4427e1e48930' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://thetuscanpaw.com/wp-content/uploads/2025/04/cropped-Logo-B_FinalWhite-2-32x32.png" sizes="32x32" />
<link rel="icon" href="https://thetuscanpaw.com/wp-content/uploads/2025/04/cropped-Logo-B_FinalWhite-2-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://thetuscanpaw.com/wp-content/uploads/2025/04/cropped-Logo-B_FinalWhite-2-180x180.png" />
<meta name="msapplication-TileImage" content="https://thetuscanpaw.com/wp-content/uploads/2025/04/cropped-Logo-B_FinalWhite-2-270x270.png" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-it-it">
	<script>
document.body.className = document.body.className.replace('no-js','js');
</script>

				<h1 class="screen-reader-text">Accedi</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://it.wordpress.org/">Powered by WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://thetuscanpaw.com/wp-login.php" method="post">
			<p>
				<label for="user_login">Nome utente o indirizzo email</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Mostra password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Ricordami</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Accedi" />
									<input type="hidden" name="redirect_to" value="https://thetuscanpaw.com/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-register" href="https://thetuscanpaw.com/wp-login.php?action=register">Registrati</a> | <a class="wp-login-lost-password" href="https://thetuscanpaw.com/wp-login.php?action=lostpassword">Password dimenticata?</a>			</p>
			<script>
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
</script>
		<p id="backtoblog">
			<a href="https://thetuscanpaw.com/">&larr; Torna a The Tuscan Paw</a>		</p>
		<div class="privacy-policy-page-link"><a class="privacy-policy-link" href="https://thetuscanpaw.com/privacy-policy-2/" rel="privacy-policy">Privacy Policy</a></div>	</div>
				<div class="language-switcher">
				<form id="language-switcher" method="get">

					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text">
							Lingua						</span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="de_DE" lang="de" data-installed="1">Deutsch</option>
<option value="es_ES" lang="es" data-installed="1">Español</option>
<option value="fr_FR" lang="fr" data-installed="1">Français</option>
<option value="it_IT" lang="it" selected='selected' data-installed="1">Italiano</option></select>
					
					
					
						<input type="submit" class="button" value="Cambia">

					</form>
				</div>
			
	<script src="https://thetuscanpaw.com/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script src="https://thetuscanpaw.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://thetuscanpaw.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script id="zxcvbn-async-js-extra">
var _zxcvbnSettings = {"src":"https:\/\/thetuscanpaw.com\/wp-includes\/js\/zxcvbn.min.js"};
</script>
<script src="https://thetuscanpaw.com/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script src="https://thetuscanpaw.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script src="https://thetuscanpaw.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script id="password-strength-meter-js-extra">
var pwsL10n = {"unknown":"Efficacia della password sconosciuta","short":"Molto debole","bad":"Debole","good":"Media","strong":"Forte","mismatch":"Mancata corrispondenza"};
</script>
<script id="password-strength-meter-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2025-04-30 18:01:46+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"it"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["%1$s \u00e8 deprecata sin dalla versione %2$s! Usa %3$s al suo posto. Prova a scrivere del codice pi\u00f9 inclusivo."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
</script>
<script src="https://thetuscanpaw.com/wp-admin/js/password-strength-meter.min.js?ver=6.8.1" id="password-strength-meter-js"></script>
<script src="https://thetuscanpaw.com/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script src="https://thetuscanpaw.com/wp-includes/js/wp-util.min.js?ver=6.8.1" id="wp-util-js"></script>
<script src="https://thetuscanpaw.com/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script id="wp-a11y-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2025-04-03 21:33:22+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"it"},"Notifications":["Notifiche"]}},"comment":{"reference":"wp-includes\/js\/dist\/a11y.js"}} );
</script>
<script src="https://thetuscanpaw.com/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14" id="wp-a11y-js"></script>
<script id="user-profile-js-extra">
var userProfileL10n = {"user_id":"0","nonce":"a79d5b4bb5"};
</script>
<script id="user-profile-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2025-04-30 18:01:46+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"it"},"Application password has been copied to your clipboard.":["La password dell'applicazione \u00e8 stata copiata negli appunti."],"Your new password has not been saved.":["La tua nuova password non \u00e8 stata salvata."],"Hide":["Nascondi"],"Confirm use of weak password":["Conferma l'uso di una password debole"],"Hide password":["Nascondi password"],"Show password":["Mostra password"],"Show":["Visualizza"],"The changes you made will be lost if you navigate away from this page.":["Se abbandoni questa pagina i cambiamenti effettuati verranno persi."]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
</script>
<script src="https://thetuscanpaw.com/wp-admin/js/user-profile.min.js?ver=6.8.1" id="user-profile-js"></script>
	</body>
	</html>
	